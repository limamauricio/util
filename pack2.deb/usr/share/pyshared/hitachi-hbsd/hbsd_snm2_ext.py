# Copyright (C) 2015, Hitachi, Ltd.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from oslo.utils import timeutils

from cinder.openstack.common import loopingcall
from cinder.volume.drivers.hitachi.hbsd import hbsd_exception as exception
from cinder.volume.drivers.hitachi.hbsd import hbsd_snm2 as snm2
from cinder.volume.drivers.hitachi.hbsd import hbsd_traceutils as traceutils
from cinder.volume.drivers.hitachi.hbsd import hbsd_utils as utils

_PAIRED = 12


class HBSDSNM2Extension(snm2.HBSDSNM2):

    @traceutils.trace_function()
    def restore_ldev(self, pvol, svol):
        self.run_aureplicationlocal('-restore', pvol, svol, True)
        self._wait_thin_copy(pvol, svol)
        self.run_aureplicationlocal('-split', pvol, svol, True)

    @traceutils.trace_function()
    def _wait_thin_copy(self, pvol, svol, **kwargs):
        interval = kwargs.pop(
            'interval', self.conf.hitachi_async_copy_check_interval)

        def _wait_for_thin_copy_status(start_time, pvol, svol, **kwargs):
            timeout = kwargs.pop('timeout', utils.MAX_PROCESS_WAITTIME)

            if self._run_aureplicationmon(pvol, svol) == _PAIRED:
                raise loopingcall.LoopingCallDone()
            if utils.check_timeout(start_time, timeout):
                raise loopingcall.LoopingCallDone(False)

        loop = loopingcall.FixedIntervalLoopingCall(
            _wait_for_thin_copy_status, timeutils.utcnow(),
            pvol, svol, **kwargs)
        if not loop.start(interval=interval).wait():
            msg = utils.output_log(611, svol=svol)
            raise exception.HBSDError(data=msg)

    @traceutils.trace_function()
    def _run_aureplicationmon(self, pvol, svol):
        result = self.run_snm2(
            'aureplicationmon', '-evwait', '-gname', 'Ungrouped', '-nowait',
            '-ss', '-pairname', 'SS_LU%(pvol)04d_LU%(svol)04d' % {
                'pvol': pvol, 'svol': svol}, noretry=True, do_raise=False,
            success_code=set(xrange(32)))
        return result[0]

    @traceutils.trace_function()
    def has_thin_copy_pair(self, pvol, svol):
        return self.run_aureplicationlocal_refer(
            '-ss', '-pvol', pvol, '-svol', svol)
