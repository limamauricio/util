# Copyright (C) 2014, 2015, Hitachi, Ltd.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
"""
Fibre channel Cinder volume driver for Hitachi storage.

"""

from oslo.config import cfg

from cinder.volume import driver
from cinder.volume.drivers.hitachi.hbsd import hbsd_common as common
from cinder.volume.drivers.hitachi.hbsd import hbsd_traceutils as traceutils
from cinder.volume.drivers.hitachi.hbsd import hbsd_utils as utils
from cinder.zonemanager import utils as fczm_utils

CONF = cfg.CONF
CONF.register_opts(common.FC_VOLUME_OPTS)


class HBSDFCDriver(driver.FibreChannelDriver):
    VERSION = common.VERSION

    def __init__(self, *args, **kwargs):
        super(HBSDFCDriver, self).__init__(*args, **kwargs)

        self.configuration.append_config_values(common.COMMON_VOLUME_OPTS)
        self.configuration.append_config_values(common.FC_VOLUME_OPTS)
        self.common = utils.import_object(
            self.configuration, 'FC', **kwargs)

        self._lookup_service = fczm_utils.create_lookup_service()

    def check_for_setup_error(self):
        pass

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def create_volume(self, volume):
        return self.common.create_volume(volume)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def create_volume_from_snapshot(self, volume, snapshot):
        return self.common.create_volume_from_snapshot(volume, snapshot)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def create_cloned_volume(self, volume, src_vref):
        return self.common.create_cloned_volume(volume, src_vref)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def delete_volume(self, volume):
        self.common.delete_volume(volume)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def create_snapshot(self, snapshot):
        return self.common.create_snapshot(snapshot)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def delete_snapshot(self, snapshot):
        self.common.delete_snapshot(snapshot)

    def local_path(self, volume):
        pass

    @traceutils.trace_function(loglevel=traceutils.DEBUG)
    def get_volume_stats(self, refresh=False):
        return self.common.get_volume_stats(refresh)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def copy_volume_data(self, context, src_vol, dest_vol, remote=None):
        super(HBSDFCDriver, self).copy_volume_data(
            context, src_vol, dest_vol, remote)
        self.common.copy_dest_vol_meta_to_src_vol(src_vol, dest_vol)
        self.common.discard_zero_page(dest_vol)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def copy_image_to_volume(self, context, volume, image_service, image_id):
        super(HBSDFCDriver, self).copy_image_to_volume(
            context, volume, image_service, image_id)
        self.common.discard_zero_page(volume)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def clone_image(self, volume, image_location, image_id, image_meta):
        return self.common.clone_image(
            volume, image_location, image_id, image_meta)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def restore_backup(self, context, backup, volume, backup_service):
        super(HBSDFCDriver, self).restore_backup(
            context, backup, volume, backup_service)
        self.common.discard_zero_page(volume)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def extend_volume(self, volume, new_size):
        self.common.extend_volume(volume, new_size)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def manage_existing(self, volume, existing_ref):
        return self.common.manage_existing(volume, existing_ref)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def manage_existing_get_size(self, volume, existing_ref):
        return self.common.manage_existing_get_size(volume, existing_ref)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def unmanage(self, volume):
        self.common.unmanage(volume)

    @traceutils.measure_exec_time
    @traceutils.logging_basemethod_exec
    def do_setup(self, context):
        self.common.do_setup(context)

    def ensure_export(self, context, volume):
        pass

    def create_export(self, context, volume):
        pass

    def remove_export(self, context, volume):
        pass

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @fczm_utils.AddFCZone
    @traceutils.logging_basemethod_exec
    def initialize_connection(self, volume, connector):
        conn_info = self.common.initialize_connection(volume, connector)
        if self.configuration.hitachi_zoning_request:
            init_targ_map = self._build_initiator_target_map(
                connector, conn_info['data']['target_wwn'])
            if init_targ_map:
                conn_info['data']['initiator_target_map'] = init_targ_map
        return conn_info

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def terminate_connection(self, volume, connector, **kwargs):
        self.common.terminate_connection(volume, connector, **kwargs)

    @traceutils.trace_function()
    def _build_initiator_target_map(self, connector, target_wwns):
        init_targ_map = {}
        initiator_wwns = connector['wwpns']
        if self._lookup_service:
            dev_map = self._lookup_service.get_device_mapping_from_network(
                initiator_wwns, target_wwns)
            for fabric_name in dev_map:
                fabric = dev_map[fabric_name]
                for initiator in fabric['initiator_port_wwn_list']:
                    init_targ_map[initiator] = fabric['target_port_wwn_list']
        else:
            for initiator in initiator_wwns:
                init_targ_map[initiator] = target_wwns
        return init_targ_map
