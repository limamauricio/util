# Copyright (C) 2014, 2015, Hitachi, Ltd.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
"""
iSCSI Cinder volume driver for Hitachi storage.

"""

from oslo.config import cfg

from cinder.volume import driver
from cinder.volume.drivers.hitachi.hbsd import hbsd_common as common
from cinder.volume.drivers.hitachi.hbsd import hbsd_traceutils as traceutils
from cinder.volume.drivers.hitachi.hbsd import hbsd_utils as utils

CONF = cfg.CONF
CONF.register_opts(common.ISCSI_VOLUME_OPTS)


class HBSDISCSIDriver(driver.ISCSIDriver):
    VERSION = common.VERSION

    def __init__(self, *args, **kwargs):
        super(HBSDISCSIDriver, self).__init__(*args, **kwargs)

        self.configuration.append_config_values(common.COMMON_VOLUME_OPTS)
        self.configuration.append_config_values(common.ISCSI_VOLUME_OPTS)
        self.common = utils.import_object(
            self.configuration, 'iSCSI', **kwargs)

    def check_for_setup_error(self):
        pass

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def create_volume(self, volume):
        return self.common.create_volume(volume)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def create_volume_from_snapshot(self, volume, snapshot):
        return self.common.create_volume_from_snapshot(volume, snapshot)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def create_cloned_volume(self, volume, src_vref):
        return self.common.create_cloned_volume(volume, src_vref)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def delete_volume(self, volume):
        self.common.delete_volume(volume)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def create_snapshot(self, snapshot):
        return self.common.create_snapshot(snapshot)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def delete_snapshot(self, snapshot):
        self.common.delete_snapshot(snapshot)

    def local_path(self, volume):
        pass

    @traceutils.trace_function(loglevel=traceutils.DEBUG)
    def get_volume_stats(self, refresh=False):
        return self.common.get_volume_stats(refresh)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def copy_volume_data(self, context, src_vol, dest_vol, remote=None):
        super(HBSDISCSIDriver, self).copy_volume_data(
            context, src_vol, dest_vol, remote)
        self.common.copy_dest_vol_meta_to_src_vol(src_vol, dest_vol)
        self.common.discard_zero_page(dest_vol)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def copy_image_to_volume(self, context, volume, image_service, image_id):
        super(HBSDISCSIDriver, self).copy_image_to_volume(
            context, volume, image_service, image_id)
        self.common.discard_zero_page(volume)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def restore_backup(self, context, backup, volume, backup_service):
        super(HBSDISCSIDriver, self).restore_backup(
            context, backup, volume, backup_service)
        self.common.discard_zero_page(volume)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def extend_volume(self, volume, new_size):
        self.common.extend_volume(volume, new_size)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def manage_existing(self, volume, existing_ref):
        return self.common.manage_existing(volume, existing_ref)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def manage_existing_get_size(self, volume, existing_ref):
        return self.common.manage_existing_get_size(volume, existing_ref)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def unmanage(self, volume):
        self.common.unmanage(volume)

    @traceutils.measure_exec_time
    @traceutils.logging_basemethod_exec
    def do_setup(self, context):
        self.common.do_setup(context)

    def ensure_export(self, context, volume):
        pass

    def create_export(self, context, volume):
        pass

    def remove_export(self, context, volume):
        pass

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def initialize_connection(self, volume, connector):
        return self.common.initialize_connection(volume, connector)

    @traceutils.measure_exec_time
    @traceutils.trace_function()
    @traceutils.logging_basemethod_exec
    def terminate_connection(self, volume, connector, **kwargs):
        self.common.terminate_connection(volume, connector, **kwargs)
